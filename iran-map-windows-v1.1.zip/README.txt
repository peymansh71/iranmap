# Iran Map - Windows Application

## Quick Start
1. Double-click `start-iran-map.bat` to run the application
2. Your browser will automatically open to http://localhost:3000
3. Close the command window to stop the application

## Alternative Start Methods
- **Batch File**: Double-click `start-iran-map.bat`
- **PowerShell**: Right-click `start-iran-map.ps1` → "Run with PowerShell"
- **Manual**: Run `iran-map-windows.exe` and open http://localhost:3000

## System Requirements
- Windows 10 or later
- Modern web browser (Chrome, Firefox, Edge)
- No additional software installation required

## Port Configuration
The application runs on port 3000. If this port is busy, the server will show an error.
To use a different port, run: `iran-map-windows.exe` with environment variable `PORT=8080`

## Troubleshooting
1. **Port already in use**: Close other applications or restart your computer
2. **Firewall warning**: Allow the application through Windows Firewall
3. **Browser doesn't open**: Manually navigate to http://localhost:3000

## Support
This is the Iran Map visualization application packaged for Windows.
Version: 1.0.0
Built: 2025-06-09T09:41:23.784Z
